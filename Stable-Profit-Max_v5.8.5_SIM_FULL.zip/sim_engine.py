# Simulation engine core
