# Main entry point
print('Running main.py')
