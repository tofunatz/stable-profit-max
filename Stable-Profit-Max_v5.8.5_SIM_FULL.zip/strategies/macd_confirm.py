# MACD strategy logic
